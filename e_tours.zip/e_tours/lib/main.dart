import 'package:flutter/material.dart';
import './userprofile.dart';
import './tour_dets.dart';
// import 'package:flutter_offline/flutter_offline.dart';

void main() {
   runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'eTours',
      theme: ThemeData(
        primarySwatch: Colors.yellow,
      ),
      home: LogIn(),
    );
  }
}

//Log in
class LogIn extends StatefulWidget{
  @override
  State createState() => LogInState();
}

class LogInState extends State<LogIn> {
  // const LogInState({Key? key,}) : super(key: key);
  bool loggedIn = false;
  String name = " ";

  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Log in or Register'),
      ),
      body: Center(
        child: loggedIn ? _buildSuccess() : _buildLoginForm(),
    ),

    );
  }

  Widget _buildSuccess() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Icon(Icons.check, color: Colors.orangeAccent),
        Text('Hi user')
      ],
    );
  }

  Widget _buildLoginForm() {
    return Form(
        key: _formKey,
        child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextFormField(
                    controller: _nameController,
                    decoration: InputDecoration(labelText: 'Name'),
                    validator: (text) {
                      if(text == null || text.isEmpty){
                        return 'Please enter name';
                      }
                      return null;
                    }
                ),
                TextFormField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(labelText: 'Email'),
                  validator: (text) {
                    if (text == null || text.isEmpty) {
                      return 'Enter your\'s email.';
                    }
                    final regex = RegExp('[^@]+@[^\.]+\..+');
                    if (!regex.hasMatch(text)) {
                      return 'Enter a valid email';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  child: Text('Log in'),
                  onPressed: (){
                      Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (_) => const MyHomePage(title: 'dashboard'))
                    );
                  }

                ),
                ElevatedButton(
                  child: Text('Register'),
                  onPressed: (){
                    Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (_) => UserProfile())
                    );
                  },
                ),

              ],
            )
        )

    );
  }

}
//Homescreen or Dashboard
class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final GlobalKey<AnimatedListState> listKey = GlobalKey<AnimatedListState>();

  final List<int> _items = [1, 2, 3, 4, 5];
  int counter = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
      ),
      body: AnimatedList(
        key: listKey,
        initialItemCount: _items.length,
        itemBuilder: (BuildContext context, int index, Animation
        animation) {
          return fadeListTile(context, index, animation);
        },
      ),
    );
      // ),
    // );
  }

  fadeListTile(BuildContext context, int index, Animation animation)
  {
    int item = _items[index];
    return FadeTransition(
      opacity: Tween(begin: 0.0, end: 1.0).animate(animation),
      child: Card(
        child: ListTile(
          title: Text('Pizza ' + item.toString(),
                  textAlign: TextAlign.left,
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),),
            onTap: (){
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => TourDets())
              );
              },
          ),
      ),
    );}
}

