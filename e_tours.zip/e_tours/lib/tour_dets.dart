import 'package:flutter/material.dart';

//Tour details page
class TourDets extends StatefulWidget{
  @override
  State createState() => TourDetsState();
}

class TourDetsState extends State<TourDets> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tour information',
          style: TextStyle(
            fontSize: 20,
          ),),
      ),
      body: Column(
        children: <Widget> [
          Text ('Personal Information',
            textAlign: TextAlign.center,),
          Row(
            children: const [
              Text('From:',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                'Point A'
                  ),

            ],
          ),
          Row(
            children: const [
              Text('To:',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                  'Point B'
              )
            ],
          ),
          Row(
            children: const [
              Text('Distance Covered:',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                  'X Km'
              )
            ],
          ),

          Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget> [
                TextButton(
                  child: Text('Book'),
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(Colors.green),
                    foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                  ),
                    onPressed: null,),
                TextButton(
                  child: Text('Back'),
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(Colors.red),
                    foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                  ),
                    onPressed: (){
                          Navigator.of(context).pop();
                  }
    ),
              ]
          ),
        ],
      ),
    );
  }

}

//Payment page
class Payment extends StatefulWidget{
  @override
  State createState() => PaymentState();
}

class PaymentState extends State<Payment> {
  final List<Color> acolors = [
    Colors.red,
    Colors.white,
  ];

  final List<Color> bcolors = [
    Colors.white,
    Colors.green,
  ];

  int iteration = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Payment Information',
          style: TextStyle(
            fontSize: 20,
          ),),
      ),
      body: Column(
        children: <Widget> [
          Text ('Card',
            textAlign: TextAlign.center,),
          Row(
            children: const [
              Text('Card number',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                // controller: controller,
                  decoration: InputDecoration(
                    labelText: '9876 5649 5647 256',
                  )
              )
            ],
          ),
          Row(
            children: const [
              Text('Expiry date',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                  decoration: InputDecoration(
                    labelText: '17/58',
                  )
              )
            ],
          ),
          Row(
            children: const [
              Text('CSV',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                  decoration: InputDecoration(
                    labelText: '568',
                  )
              )
            ],
          ),
          Row(
            children: const [
              Text('Name on Card',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                  decoration: InputDecoration(
                    labelText: 'Micheal Nyathi',
                  )
              )
            ],
          ),
          TextButton(
            child: Text('Pay with card'),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.green),
              foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
            ),
            onPressed: null,
          ),
          Text ('Coupon',
            textAlign: TextAlign.center,),
          Row(
            children: const [
              Text('Coupon number',
                textAlign: TextAlign.left,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              TextField(
                // controller: controller,
                  decoration: InputDecoration(
                    labelText: '7569-5689-ADS5',
                  )
              )
            ],
          ),

          TextButton(
              child: Text('Pay with coupon'),
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(Colors.green),
                foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
            ),
            onPressed:  () {
              iteration < acolors.length - 1 ? iteration++ : iteration = 0;
              setState(() {
                iteration = iteration;
              });}
          ),
          TextButton(
              child: Text('Back'),
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(Colors.red),
                foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
              ),
              onPressed: (){
                Navigator.of(context).pop();
              }
          ),
        ],
      ),
    );
  }
}